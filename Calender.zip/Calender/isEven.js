
//calender;
function calender(){
    //all variables
    var monthName=document.getElementById("greanteName").value;
    var totalDays=document.getElementById("TotalDays").value;
    var startingDay=document.getElementById("startingDay").value;

    //css;
    document.getElementById("textt").innerHTML="Please open console.<strong>(ctrl+shift+i)</strong>";
    document.getElementById("greanteName").style.textTransform="capitalize"

    //days and month name;
    console.log("\n\n",monthName);
    console.log("\n","Sun  Mon  Thu  Wed  Tue  Fri  Sat");

    //calender loop;
    for(var i=0; i<6; i++){
        var dayRow=" ";
            for(var j=1; j<=7; j++){
                var currentDay=7*i+j-startingDay;
                if(currentDay>totalDays){
                    break;
                } else if(currentDay<1){
                    currentDay=" ";
                }
                if(currentDay>9){
                    dayRow+=currentDay+"   ";
                } else{
                    dayRow+=currentDay+"    ";
                }
            }
        console.log(dayRow);
    }

    //from validation;
    if(monthName=="" || monthName==" "){
        alert("input a MontName")
    } else if(totalDays=="" || totalDays==" " || isNaN(totalDays)){
        alert("input a Total MontDays")
    } else if(startingDay=="" || startingDay==" " || isNaN(startingDay)){
        alert("input a Total MontDays")
    } else if(startingDay>7){
        alert("Greater Then 7. Maximum number 7")
    } else if(startingDay<1){
        alert("Less Then 7. Minimum number 7")
    }
    
}